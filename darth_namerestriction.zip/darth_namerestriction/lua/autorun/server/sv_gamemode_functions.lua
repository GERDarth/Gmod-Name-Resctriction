local disallowedNames = {["ooc"] = true, ["shared"] = true, ["world"] = true, ["world prop"] = true}
hook.Add("CanChangeRPName", "MyRules", function(ply, RPname)
	if disallowedNames[string.lower(RPname)] then return false, "Nom RP refusé." end
	
	local len = string.len(RPname)
	if len > 35 then return false, "(RP Name too long/Nom RP trop long)" end
	if len < 6 then return false, "(RP Name too short/Nom RP trop court)" end
	return true 
end)